<header>
    <div class="mini_header">
        <div class="mini_header_wrapper">
            <div class="burger_btn" id="burger_btn">
                <img src="img/icons/burger.svg" alt="картинка бургер меню">
            </div>
            <div class="mini_header_left">
                <img src="img/icons/time.svg" alt="иконка часов" class="mini_header_left_time_img">
                <span class="mini_header_left_text">
                    Работаем ежедневно:
                </span>
                <span class="mini_header_left_time_work">с 08:00 до 21:00</span>
            </div>
            <div class="mini_header_center">
                <a target="_blank" href="https://t.me/prekrasnaya_podkastnaya" class="mini_header_center_item">
                    <div class="mini_header_center_item_icon_wrapper">
                        <img src="img/icons/telegram-brands.svg" alt="иконка TG"
                            class="mini_header_center_item_icon_img">
                    </div>
                    <span class="mini_header_center_item_icon_text">Telegram</span>
                </a>
                <a target="_blank" href="https://vk.com/club230189528" class="mini_header_center_item">
                    <div class="mini_header_center_item_icon_wrapper">
                        <img src="img/icons/vk.svg" alt="иконка вк" class="mini_header_center_item_icon_img">
                    </div>
                    <span class="mini_header_center_item_icon_text">Вконтакте</span>
                </a>
                <!-- <a target="_blank" href="https://api.whatsapp.com/send/?phone=79859243534"
                    class="mini_header_center_item">
                    <div class="mini_header_center_item_icon_wrapper">
                        <img src="img/icons/whatsapp-brands.svg" alt="иконка однокласники"
                            class="mini_header_center_item_icon_img">
                    </div>
                    <span class="mini_header_center_item_icon_text">WhatsApp</span>
                </a> -->
            </div>
            <div class="mini_header_right">
                <img src="img/icons/map.svg" alt="иконка карты" class="mini_header_right_map_img">
                <span class="mini_header_right_text">
                    Адрес:
                </span>
                <a href="https://yandex.ru/maps/-/CHb052Zw" target="_blank" class="mini_header_right_link_adress">
                    г. МОсква, ул. Студенческая 22к1, Кутузовский проспект </a>
            </div>
        </div>
    </div>
    <div class="main_header">
        <div class="main_header_wrapper">
            <a href="/" class="main_header_logo">
                <img src="img/logo.png" alt="логотип компании" class="main_header_logo_img">
            </a>
            <div class="main_header_menu">
                <div class="main_header_menu_ul">
                    <!-- <a href="index.php" class="main_header_menu_ul_item <?= $main ?>">
                        <li class="main_header_menu_ul_item_text">Главная</li>
                    </a>
                    <a href="about.php" class="main_header_menu_ul_item <?= $about1 ?>">
                        <li class="main_header_menu_ul_item_text">О нас</li>
                    </a>
                    <a href="services.php" class="main_header_menu_ul_item <?= $service ?>">
                        <li class="main_header_menu_ul_item_text">Услуги</li>
                    </a>
                    
                    <a href="faq.php" class="main_header_menu_ul_item <?= $faq ?>">
                        <li class="main_header_menu_ul_item_text">Вопросы и
                            ответы</li>
                    </a>
                    <a href="contacts.php" class="main_header_menu_ul_item <?= $contacts ?>">
                        <li class="main_header_menu_ul_item_text">Контакты</li>
                    </a>
                    <a href="articles.php" class="main_header_menu_ul_item <?= $articles ?>">
                        <li class="main_header_menu_ul_item_text">Статьи</li>
                    </a> -->

                    <a href="/" class="main_header_menu_ul_item <?= $main ?> ">
                        <li class="main_header_menu_ul_item_text">Главная</li>
                    </a>
                    <a href="#about" class="main_header_menu_ul_item <?= $about1 ?> scroll-link">
                        <li class="main_header_menu_ul_item_text">О нас</li>
                    </a>
                    <a href="#location" class="main_header_menu_ul_item <?= $faq ?> scroll-link">
                        <li class="main_header_menu_ul_item_text">Локации</li>
                    </a>
                    <a href="#oborydovanie" class="main_header_menu_ul_item <?= $contacts ?> scroll-link">
                        <li class="main_header_menu_ul_item_text">Оборудование</li>
                    </a>
                    <a href="/blog.php" class="main_header_menu_ul_item <?= blog.php ?>">
                        <li class="main_header_menu_ul_item_text">Блоги</li>
                    </a>
                    <a href="/viezd.php" class="main_header_menu_ul_item <?= viezd.php ?>">
                        <li class="main_header_menu_ul_item_text">Выездные съёмки</li>
                    </a>
<?php if (basename($_SERVER['SCRIPT_NAME']) === 'index.php'): ?>
    <a href="#services" class="main_header_menu_ul_item scroll-link">
        <li class="main_header_menu_ul_item_text">Услуги</li>
    </a>
<?php endif; ?>

                    </a>
</div>
            </div>
            <div class="main_header_call_block">
                <div class="main_header_call_block_item">
                    <img src="img/icons/phone.svg" alt="иконка телефона" class="main_header_call_block_left_img">
                    <a target="_blank" href="tel: +7(985)924-35-34" class="main_header_call_block_right_phone">+7(985)924-35-34</a>
                    <!-- <a target="_blank" href="tel: +7 (495) 924-35-34" class="main_header_call_block_right_phone">+7
                        (495)
                        924-35-34</a> -->
                </div>
                <div class="main_header_call_block_item">
                    <img src="img/icons/whatsapp-brands.svg" alt="иконка ватсап"
                        class="main_header_call_block_left_img">
                    <a target="_blank" href="https://api.whatsapp.com/send/?phone=79859243534"
                        class="main_header_call_block_right_phone"
                        onclick="yaCounter101462745.reachGoal('WA'); return true;">+7(985)924-35-34</a>
                </div>
            </div>
        </div>
    </div>
</header>

<div class="header_mobile_podlojka">
    <div class="header_mobile">
        <div class="header_mobile_item_top_arrow" id="close_burger_menu">
            <svg data-name="Capa 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512"
                data-prefix="ijzj0hv7b">
                <path
                    d="M512 30.17L481.83 0 256 225.83 30.17 0 0 30.17 225.83 256 0 481.83 30.17 512 256 286.17 481.83 512 512 481.83 286.17 256z"
                    class="path-i4htnuep0"></path>
            </svg>
        </div>
        <a href="#ofer" class="header_mobile_item scroll-link">
            Главная
        </a>
        <a href="#about" class="header_mobile_item scroll-link">
            О нас
        </a>
        <a href="#location" class="header_mobile_item scroll-link">
            Локации
        </a>
        <a href="#oborydovanie" class="header_mobile_item scroll-link">
            Оборудование
        </a>
        <a href="#services" class="header_mobile_item scroll-link">
            Услуги
        </a>
        <a href="/blog.php" class="header_mobile_item">
            Блоги
        </a>
        <a href="/viezd.php" class="header_mobile_item">
            Выездные съёмки
        </a>
    </div>
</div>
<div class="popup" id="popup">
    <div class="popup_wrapper">
        <div class="popup_content">
            <div class="popup_content_close_btn" id="close_popup">
                <svg data-name="Capa 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512"
                    height="512" data-prefix="i1y0g7pzc">
                    <path
                        d="M512 30.17L481.83 0 256 225.83 30.17 0 0 30.17 225.83 256 0 481.83 30.17 512 256 286.17 481.83 512 512 481.83 286.17 256z"
                        class="path-ij1hf145k"></path>
                </svg>
            </div>
            <p class="popup_content_title">
                Оставьте заявку
            </p>
            <p class="popup_content_sub_title">
                Наши менеджеры свяжутся с Вами в течение 5 минут
            </p>
            <form method="post" action="thanks.php" class="popup_content_form" id="popup_content_form">
                <input type="text" name="name" class="popup_content_form_input" required placeholder="Ваше имя">
                <input type="text" name="phone" id="phone" placeholder="+7 (999) 999-99-99"
                    class="popup_content_form_input" required>
                <!-- minlength="17" maxlength="17" -->
                <label>
                    <input type="checkbox" class="custom-radio" name="agreement" value="yes" required>
                    <span class="custom-radio-label">Нажимая на кнопку, я даю согласие на обработку своих персональных
                        данных</span>
                </label>
                <button class="popup_content_form_btn"
                    onclick="yaCounter101462745.reachGoal ('order'); return true;">Отправить запрос</button>
                <div id="error" style="color: red; display: none;">Некорректный номер телефона</div>
            </form>
        </div>
    </div>
</div>