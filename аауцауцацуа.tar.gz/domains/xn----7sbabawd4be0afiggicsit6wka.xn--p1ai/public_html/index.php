<?php require_once __DIR__ . '/autoseo.php'; ?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <!-- === SEO‑базис для Прекрасная‑Подкастная.рф === -->
    <link rel="canonical" href="https://прекрасная-подкастная.рф/">
<meta name="p:domain_verify" content="c11fd3451048c4a58a0c8b945b2947ba"/>
    <!-- Open Graph -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://прекрасная-подкастная.рф/">
    <meta property="og:title" content="Студия подкастов и видеозаписи в Москве">
    <meta property="og:description"
        content="Снимем подкаст и коммерческое видео в 4К на Sony FX30, звук - Shure SM7DB. Находимся рядом с Москва-Сити, на Кутузовском пр. Скидка 50 % для новых клиентов. Пишите в WhatsApp: +7(985)924-35-34">
    <meta property="og:image" content="https://прекрасная-подкастная.рф/img/og_cover.webp">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Студия подкастов и видеозаписи">
    <meta name="twitter:description" content="Запишите идеальный подкаст или видео в 4К. Находимся центре Москвы, 5 минут от Москва-сити, Кутузовский проспект. Есть бесплатная парковка. Скидка 50 % для новых клиентов. Пишите в WhatsApp: +7(985)924-35-34">
    <meta name="twitter:image" content="https://прекрасная-подкастная.рф/img/og_cover.webp">

    <!-- Быстрый коннект к CDN -->
    <link rel="preconnect" href="https://cdn.jsdelivr.net">
    <link rel="dns-prefetch" href="https://cdn.jsdelivr.net">

    <!-- JSON‑LD -->
    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": ["Organization", "LocalBusiness", "AudioVisualStudio"],
  "name": "Прекрасная Подкастная",
  "alternateName": "Студия записи подкастов в Москве",
  "description": "Профессиональная студия для записи подкастов и видеоконтента с современным оборудованием и звукоизоляцией. Находимся на Кутузовском проспекте. Есть бесплатная парковка. Скидка 50% для новых клиентов. Пишите в WhatsApp: +7(985)924-35-34",
  "url": "https://прекрасная-подкастная.рф",
  "logo": "https://прекрасная-подкастная.рф/img/logo.png",
  "telephone": "+7 (985) 924-35-34",
  "email": "402332@mail.ru",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "ул. Студенческая, д. 22, корпус 1",
    "addressLocality": "Москва",
    "postalCode": "119899",
    "addressCountry": "RU"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": "55.738",
    "longitude": "37.53"
  },
  "openingHoursSpecification": {
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    "opens": "09:00",
    "closes": "21:00"
  },
  "priceRange": "$$",
  "sameAs": [
    "https://vk.com/prekrasnaya_podkastnaya",
    "https://t.me/prekrasnaya_podkastnaya"
  ]
}
</script>
    <!-- === /SEO‑базис === -->

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/lightboxjs.min.css" />
    <?php $main = 'active'; ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <link rel="icon" href="img/favicon.ico" type="image/x-icon">
    <title>Студия подкастов и видеозаписи в Москве | Прекрасная Подкастная </title>
    <meta name="description"
        content="Видеостудия в центре Москвы для записи подкастов и коммерческого видео. Профессиональное оборудование: камеры Sony fx30, микрофоны Shure, свет Godox. Идеальная локация на Кутузовском проспекте с бесплатной парковкой. Скидки до 50%. Пишите в WhatsApp: +7 (985) 924-35-34">
    <meta name="yandex-verification" content="b9b679576df4dce1" />
    <meta name="google-site-verification" content="74NqRpVhE8-JUK8_WGdomxBVl9tEIX4devXRyks8r7s" />
</head>

<body>
    <?php include 'include/header.php'; ?>
    <main>
        <section class="ofer" id="ofer">
            <div class="ofer_wrapper">
                <img src="img/back_ofer.jpg" alt="фото для офера" loading="lazy" decoding="async"
                    class="ofer_wrapper_img">
                <div class="ofer_overlay">
                    <div class="ofer_overlay_wrapper">
                        <div class="ofer_overlay_left">
                            <h1 class="ofer_overlay_left_title">
                                Студия видеозаписи и подкастов. Кутузовский пр.<strong> Подкаст на 3 камеры - 3500 руб/час</strong>
                            </h1>
                            <p class="ofer_overlay_left_text">
                                - Топовое оборудование <br>
                                - Идеальный звук и картинка <br>
                                - Бесплатная парковка <br>
                            </p>
                            <!-- <h2 class="ofer_overlay_left_sub_title">
                                для подкастов, интервью, видеокурсов, медитаций, и других форматов
                            </h2> -->

                            <div class="ofer_overlay_left_button_block">
                                <div class="ofer_overlay_left_button_block_btn open_popup">
                                    скидка 50% для новых клиентов
                                </div>
                                <!-- <span class="ofer_overlay_left_button_block_text">
                                    Перезвоним через 5 минут!
                                </span> -->
                            </div>
                        </div>
                        <div class="ofer_overlay_right">
                            <div class="ofer_overlay_right_one_block">
                                <div class="ofer_overlay_right_one_block_top">
                                    <img src="img/icons/podcast.png" loading="lazy" decoding="async"
                                        alt="иконка наушников" class="ofer_overlay_right_one_block_top_img">
                                    <span class="ofer_overlay_right_one_block_top_text">20</span>
                                </div>
                                <div class="ofer_overlay_right_one_block_center">
                                    единиц лучшей техники <br> для видеозаписи и звука
                                </div>
                                <!-- <div class="ofer_overlay_right_one_block_bottom">
                                    Примерное описание
                                </div> -->
                            </div>
                            <div class="ofer_overlay_right_one_block">
                                <div class="ofer_overlay_right_one_block_top">
                                    <img src="img/icons/studio-mixer.png" alt="иконка пульта"
                                        class="ofer_overlay_right_one_block_top_img">
                                    <span class="ofer_overlay_right_one_block_top_text">65</span>
                                </div>
                                <div class="ofer_overlay_right_one_block_center">
                                    видов декора под любой дизайн
                                </div>
                                <!-- <div class="ofer_overlay_right_one_block_bottom">
                                    Примерное описание
                                </div> -->
                            </div>
                        </div>
                        <!-- <div class="ofer_overlay_mail_block">
                            <div class="ofer_overlay_mail_block_left">
                                <img src="img/icons/email.svg" loading="lazy" decoding="async" alt="иконка почты"
                                    class="ofer_overlay_mail_block_left_img">
                            </div>
                            <div class="ofer_overlay_mail_block_right">
                                <div class="ofer_overlay_mail_block_right_text">
                                    Пишите нам на почту:
                                </div>
                                <a href="mailto:402332@mail.ru"
                                    class="ofer_overlay_mail_block_right_link">402332@mail.ru</a>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>

        </section>
        <section class="about" id="about">
            <div class="about_wrapper">
                <div class="about_left">
                    <span class="about_left_text">
                        <strong>Full-cycle</strong> видеостудия - от идеи до продвижения
                    </span>
                    <!-- <h2 class="about_left_title">
                        О компании
                    </h2> -->
                    <div class="about_left_micro_block">
                        <!-- <img src="img/micro.webp" alt="фото микрофона" loading="lazy" decoding="async" class="about_left_micro_block_img"> -->
                        <img src="img/logo.png" loading="lazy" decoding="async" alt="фото микрофона"
                            class="about_left_micro_block_img">
                        <!-- <div class="about_left_micro_block_wrapper">
                            <span class="about_left_micro_block_span_one">
                                Работаем с
                            </span>
                            <span class="about_left_micro_block_span_two">
                                20
                            </span>
                            <span class="about_left_micro_block_span_three">
                                06
                            </span>
                            <span class="about_left_micro_block_span_four">
                                года
                            </span>
                        </div> -->
                    </div>
                </div>
                <div class="about_right">
                    <p class="about_right_text_one">
                        <strong>Студия видеозаписи и подкастов</strong> — это пространство для креативных людей и
                        бизнеса, где каждый
                        может получить профессиональную поддержку и техническое оборудование для записи контента
                        высокого качества. Мы поможем вам создать подкаст, снять видеоблог или коммерческое видео, не
                        тратя время на поиски оборудования, настройку и обучение.
                    </p>
                    <p class="about_right_text_one">
                        <strong>Команда профессионалов:</strong> маркетологи, продюсеры, видеооператоры, монтажеры, PR и
                        SMM специалисты
                    </p>
                    <p class="about_right_text_one">
                        <strong>Профессиональное оборудование:</strong> Sony, Shure, Godox
                    </p>
                    <p class="about_right_text_one">
                        <strong> Отличная локация:</strong> Кутузовский проспект, м. Студенческая (7 минут пешком) <br>
                        Бесплатная
                        парковка
                    </p>
                    <div class="about_right_call_btn ofer_overlay_left_button_block_btn open_popup">
                        заказать обратный звонок
                    </div>
                    <div class="about_right_priemushestva">
                        <div class="about_right_priemushestva_item">
                            <div class="about_right_priemushestva_item_img_block">
                                <img src="img/icons/micro.png" loading="lazy" decoding="async" alt="иконка качества"
                                    class="about_right_priemushestva_item_img_block_img">
                                <!-- <span class="about_right_priemushestva_item_img_block_number">
                                    01
                                </span> -->
                            </div>
                            <div class="about_right_priemushestva_item_name">
                                качественное оборудование
                            </div>
                            <!-- <div class="about_right_priemushestva_item_description">
                                 
                            </div> -->
                        </div>
                        <div class="about_right_priemushestva_item">
                            <div class="about_right_priemushestva_item_img_block">
                                <img src="img/icons/map.png" loading="lazy" decoding="async" alt="иконка качества"
                                    class="about_right_priemushestva_item_img_block_img">
                                <!-- <span class="about_right_priemushestva_item_img_block_number">
                                    02
                                </span> -->
                            </div>
                            <div class="about_right_priemushestva_item_name">
                                отличное местоположение
                            </div>
                            <!-- <div class="about_right_priemushestva_item_description">
                                 
                            </div> -->
                        </div>
                        <div class="about_right_priemushestva_item">
                            <div class="about_right_priemushestva_item_img_block">
                                <img src="img/icons/team.png" loading="lazy" decoding="async" alt="иконка качества"
                                    class="about_right_priemushestva_item_img_block_img">
                                <!-- <span class="about_right_priemushestva_item_img_block_number">
                                    02
                                </span> -->
                            </div>
                            <div class="about_right_priemushestva_item_name">
                                опытная <br> команда
                            </div>
                            <!-- <div class="about_right_priemushestva_item_description">
                                 
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="location" id="location">
            <div class="location_wrapper">
                <span class="location_sub_title">
                    6 различных вариантов локаций
                </span>
                <h2 class="location_title">
                    оформление декором в вашей стилистике
                </h2>
                <div class="super_wrapper_swiper_location">
                    <div class="swiper-button-prev swiper-button-prev_location"></div>
                    <div class="swiper swiper_location">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide swiper-slide_location">
                                <div class="swiper-slide-content  swiper-slide-content_location">
                                    <a href="img/location/1.jpg" data-fslightbox="swiper1">
                                        <img src="img/location/1.jpg" loading="lazy" decoding="async"
                                            alt="картинка рекордер" class="swiper-slide-content_location_img">
                                    </a>

                                    <div class="swiper-slide-content_location_btn open_popup"> Забронировать со скидкой
                                        50%</div>
                                </div>
                            </div>

                            <div class="swiper-slide swiper-slide_location">
                                <div class="swiper-slide-content  swiper-slide-content_location">
                                    <a href="img/location/2.jpg" data-fslightbox="swiper1">
                                        <img src="img/location/2.jpg" loading="lazy" decoding="async"
                                            alt="картинка рекордер" class="swiper-slide-content_location_img">
                                    </a>

                                    <div class="swiper-slide-content_location_btn open_popup"> Забронировать со скидкой
                                        50%</div>
                                </div>
                            </div>

                            <div class="swiper-slide swiper-slide_location">
                                <div class="swiper-slide-content  swiper-slide-content_location">
                                    <a href="img/location/3.jpg" data-fslightbox="swiper1">
                                        <img src="img/location/3.jpg" loading="lazy" decoding="async"
                                            alt="картинка рекордер" class="swiper-slide-content_location_img">
                                    </a>

                                    <div class="swiper-slide-content_location_btn open_popup"> Забронировать со скидкой
                                        50%</div>
                                </div>
                            </div>

                            <div class="swiper-slide swiper-slide_location">
                                <div class="swiper-slide-content  swiper-slide-content_location">
                                    <a href="img/location/4.jpg" data-fslightbox="swiper1">
                                        <img src="img/location/4.jpg" loading="lazy" decoding="async"
                                            alt="картинка рекордер" class="swiper-slide-content_location_img">
                                    </a>

                                    <div class="swiper-slide-content_location_btn open_popup"> Забронировать со скидкой
                                        50%</div>
                                </div>
                            </div>
                            <div class="swiper-slide swiper-slide_location">
                                <div class="swiper-slide-content  swiper-slide-content_location">
                                    <a href="img/location/5.jpg" data-fslightbox="swiper1">
                                        <img src="img/location/5.jpg" loading="lazy" decoding="async"
                                            alt="картинка рекордер" class="swiper-slide-content_location_img">
                                    </a>

                                    <div class="swiper-slide-content_location_btn open_popup"> Забронировать со скидкой
                                        50%</div>
                                </div>
                            </div>
                            <div class="swiper-slide swiper-slide_location">
                                <div class="swiper-slide-content  swiper-slide-content_location">
                                    <a href="img/location/6.jpg" data-fslightbox="swiper1">
                                        <img src="img/location/6.jpg" loading="lazy" decoding="async"
                                            alt="картинка рекордер" class="swiper-slide-content_location_img">
                                    </a>

                                    <div class="swiper-slide-content_location_btn open_popup"> Забронировать со скидкой
                                        50%</div>
                                </div>
                            </div>


                        </div>
                    </div>
                    <div class="swiper-button-next swiper-button-next_location"></div>
                </div>
            </div>
        </section>
        <section class="oborydovanie" id="oborydovanie">
            <div class="oborydovanie_wrapper">
                <span class="oborydovanie_sub_title">
                    топовое оборудование для видеосъемок
                </span>
                <h2 class="oborydovanie_title">
                    для идеального видео и звука
                </h2>
                <div class="super_wrapper_swiper_oborydovanie">
                    <div class="swiper-button-prev swiper-button-prev_oborydovanie"></div>
                    <div class="swiper swiper_oborydovanie">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide swiper-slide_oborydovanie">
                                <div class="swiper-slide-content  swiper-slide-content_oborydovanie">
                                    <img src="img/oborydovanie/sony_fx30_00.jpg" loading="lazy" decoding="async"
                                        alt="картинка Камеры Sony FX30" class="swiper-slide-content_oborydovanie_img">
                                    <div class="swiper-slide-title swiper-slide-title_oborydovanie">Камеры Sony FX30
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide swiper-slide_oborydovanie">
                                <div class="swiper-slide-content  swiper-slide-content_oborydovanie">
                                    <img src="img/oborydovanie/micro_shure.jpg" loading="lazy" decoding="async"
                                        alt="картинка Микрофоны Shure SM7B"
                                        class="swiper-slide-content_oborydovanie_img">
                                    <div class="swiper-slide-title swiper-slide-title_oborydovanie">Микрофоны Shure SM7B
                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide swiper-slide_oborydovanie">
                                <div class="swiper-slide-content  swiper-slide-content_oborydovanie">
                                    <img src="img/oborydovanie/godox.jpg" loading="lazy" decoding="async"
                                        alt="картинка Световое оборудование Godox"
                                        class="swiper-slide-content_oborydovanie_img">
                                    <div class="swiper-slide-title swiper-slide-title_oborydovanie">Световое
                                        оборудование Godox</div>
                                </div>
                            </div>

                            <div class="swiper-slide swiper-slide_oborydovanie">
                                <div class="swiper-slide-content  swiper-slide-content_oborydovanie">
                                    <img src="img/oborydovanie/telesuflor.png" loading="lazy" decoding="async"
                                        alt="картинка Телесуфлёр" class="swiper-slide-content_oborydovanie_img">
                                    <div class="swiper-slide-title swiper-slide-title_oborydovanie">Телесуфлёр </div>
                                </div>
                            </div>

                            <div class="swiper-slide swiper-slide_oborydovanie">
                                <div class="swiper-slide-content  swiper-slide-content_oborydovanie">
                                    <img src="img/oborydovanie/3.webp" loading="lazy" decoding="async"
                                        alt="картинка Наушники" class="swiper-slide-content_oborydovanie_img">
                                    <div class="swiper-slide-title swiper-slide-title_oborydovanie">Наушники</div>
                                </div>
                            </div>
                            <div class="swiper-slide swiper-slide_oborydovanie">
                                <div class="swiper-slide-content  swiper-slide-content_oborydovanie">
                                    <img src="img/oborydovanie/2.webp" loading="lazy" decoding="async"
                                        alt="картинка рекордер" class="swiper-slide-content_oborydovanie_img">
                                    <div class="swiper-slide-title swiper-slide-title_oborydovanie">Звук</div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="swiper-button-next swiper-button-next_oborydovanie"></div>
                </div>
            </div>
        </section>
        <section class="services">
            <div class="services_wrapper">
                <!-- <div class="services_sub_title">
                    Видеостудия полного цикла
                </div> -->
                <h2 class="services_title">
                    Кто наши клиенты:
                </h2>
                <div class="services_block">
                    <div class="services_block_item">
                        <div class="services_block_item_left">
                            <img src="img/clients/1.jpg" loading="lazy" decoding="async" alt="услуга запись подкаста"
                                class="services_block_item_left_img">
                        </div>
                        <div class="services_block_item_right">
                            <div class="services_block_item_right_bottom clients">
                                <div class="services_block_item_right_bottom_name">
                                    <strong>Корпоративные клиенты <br> (компании и предприниматели)</strong>
                                </div>
                                <div class="services_block_item_right_bottom_description">
                                    - Поможем записать видео о Вашей компании. <br> - Видеообзор Вашего продукта <br> -
                                    Видеоинструкции для сотрудников <br> - Реклама
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="services_block_item">
                        <div class="services_block_item_left">
                            <img src="img/clients/2.jpg" loading="lazy" decoding="async" alt="услуга монтаж подкаста"
                                class="services_block_item_left_img">
                        </div>
                        <div class="services_block_item_right">
                            <div class="services_block_item_right_bottom clients">
                                <div class="services_block_item_right_bottom_name">
                                    <strong>Подкастеры и блогеры</strong>
                                </div>
                                <div class="services_block_item_right_bottom_description">
                                    - Поможем с идеей <br>
                                    - Напишем сценарий <br>
                                    - Снимем видео в лучшем виде <br>
                                    - Продвинем канал, группу, личный блог<br>
                                    - Форматы: видео, аудио и текст
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="services_block_item">
                        <div class="services_block_item_left">
                            <img src="img/clients/3.jpg" loading="lazy" decoding="async" alt="услуга запись подкаста"
                                class="services_block_item_left_img">
                        </div>
                        <div class="services_block_item_right">
                            <div class="services_block_item_right_bottom clients">
                                <div class="services_block_item_right_bottom_name">
                                    <strong>Психологи, коучи, учителя, лекторы</strong>
                                </div>
                                <div class="services_block_item_right_bottom_description">
                                    Поможем записать: <br>
                                    - Онлайн-курс <br>
                                    - Видеоуроки <br>
                                    - Медитации<br>
                                    - Короткие видео
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="services_block_item">
                        <div class="services_block_item_left">
                            <img src="img/clients/4.jpg" loading="lazy" decoding="async" alt="услуга монтаж подкаста"
                                class="services_block_item_left_img">
                        </div>
                        <div class="services_block_item_right">
                            <div class="services_block_item_right_bottom clients">
                                <div class="services_block_item_right_bottom_name">
                                    <strong>Контент мейкеры и будущие звёзды </strong>
                                </div>
                                <div class="services_block_item_right_bottom_description">
                                    - Поможем выбрать нишу для контента <br>
                                    - Снимем видео под ключ <br>
                                    - Продвинем контент в массы <br>
                                    - Сделаем из вас звезду
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="steps">
            <div class="steps_wrapper">
                <h2 class="steps_title">
                    Подарки при аренде студии
                </h2>
                <div class="steps_item">
                    <div class="steps_item_top">
                        <div class="steps_item_top_number">
                            01
                        </div>
                        <!-- <div class="steps_item_top_title">
                            шаг
                        </div> -->
                        <!-- <img src="img/icons/recording.webp"  loading="lazy" decoding="async" alt="иконка записи" class="steps_item_top_img"> -->
                    </div>
                    <div class="steps_item_title">
                        Заставка для видео
                    </div>
                    <div class="steps_item_description">
                        при аренде от 2х часов
                    </div>
                </div>
                <div class="steps_item">
                    <div class="steps_item_top">
                        <div class="steps_item_top_number">
                            02
                        </div>
                        <!-- <div class="steps_item_top_title">
                            шаг
                        </div> -->
                        <!-- <img src="img/icons/video-editing_1.webp"  loading="lazy" decoding="async" alt="иконка продакшана" class="steps_item_top_img"> -->
                    </div>
                    <div class="steps_item_title">
                        Монтаж 3-х шортсов
                    </div>
                    <div class="steps_item_description">
                        при аренде от 3х часов
                    </div>
                </div>
                <div class="steps_item">
                    <div class="steps_item_top">
                        <div class="steps_item_top_number">
                            03
                        </div>
                        <!-- <div class="steps_item_top_title">
                            шаг
                        </div> -->
                        <!-- <img src="img/icons/galaxy.webp"  loading="lazy" decoding="async" alt="иконка подкаста" class="steps_item_top_img"> -->
                    </div>
                    <div class="steps_item_title">
                        Скидка до 50%
                    </div>
                    <div class="steps_item_description">
                        Индивидуальные условия для блогеров
                    </div>
                </div>
            </div>
        </section>
        <section class="services" id="services">
            <div class="services_wrapper">
                <div class="services_sub_title">
                    студия полного цикла
                </div>
                <h2 class="services_title">
                    от идеи для видео или подкаста,<br> до продвижения
                </h2>
                <div class="services_block">
                    <div class="services_block_item">
                        <div class="services_block_item_left">
                            <img src="img/services/1.jpg" loading="lazy" decoding="async" alt="услуга запись подкаста"
                                class="services_block_item_left_img">
                        </div>
                        <div class="services_block_item_right">
                            <div class="services_block_item_right_top">
                                <div class="services_block_item_right_top_arrow">
                                    <img src="img/icons/arrow.svg" class="services_block_item_right_top_arrow_img"
                                        loading="lazy" decoding="async" alt="иконка стрелки">
                                </div>
                                <div class="services_block_item_right_top_price">
                                    от <strong>777</strong> ₽/час
                                </div>
                            </div>
                            <div class="services_block_item_right_bottom">
                                <div class="services_block_item_right_bottom_name">
                                    <strong>Аренда студии видеозаписи</strong>
                                </div>
                                <div class="services_block_item_right_bottom_description">
                                    - Аренда видеостудии без оборудования и оператора <br>
                                    - Аренда видеостудии с оборудованием и оператором
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="services_block_item">
                        <div class="services_block_item_left">
                            <img src="img/services/2.jpg" loading="lazy" decoding="async" alt="услуга монтаж подкаста"
                                class="services_block_item_left_img">
                        </div>
                        <div class="services_block_item_right">
                            <div class="services_block_item_right_top">
                                <div class="services_block_item_right_top_arrow">
                                    <img src="img/icons/arrow.svg" class="services_block_item_right_top_arrow_img"
                                        loading="lazy" decoding="async" alt="иконка стрелки">
                                </div>
                                <div class="services_block_item_right_top_price">
                                    от <strong>3000</strong> ₽
                                </div>
                            </div>
                            <div class="services_block_item_right_bottom">
                                <div class="services_block_item_right_bottom_name">
                                    <strong>Идея и сценарий видео</strong>
                                </div>
                                <div class="services_block_item_right_bottom_description">
                                    Топовые продюсеры и маркетологи проведут анализ целевой аудитории, придумают идею
                                    для видео, подкаста или рилс, напишут сценарий.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="services_block_item">
                        <div class="services_block_item_left">
                            <img src="img/services/3.jpg" loading="lazy" decoding="async" alt="услуга запись подкаста"
                                class="services_block_item_left_img">
                        </div>
                        <div class="services_block_item_right">
                            <div class="services_block_item_right_top">
                                <div class="services_block_item_right_top_arrow">
                                    <img src="img/icons/arrow.svg" class="services_block_item_right_top_arrow_img"
                                        loading="lazy" decoding="async" alt="иконка стрелки">
                                </div>
                                <div class="services_block_item_right_top_price">
                                    от <strong>7500</strong> ₽/час
                                </div>
                            </div>
                            <div class="services_block_item_right_bottom">
                                <div class="services_block_item_right_bottom_name">
                                    <strong>Профессиональный видеомонтаж</strong>
                                </div>
                                <div class="services_block_item_right_bottom_description">
                                    - Черновой вариант монтажа через 48 часов <br>
                                    - Правки до идеального варианта <br>
                                    - Аудиоформат и транскрибация текстом
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="services_block_item">
                        <div class="services_block_item_left">
                            <img src="img/services/4.jpg" loading="lazy" decoding="async" alt="услуга монтаж подкаста"
                                class="services_block_item_left_img">
                        </div>
                        <div class="services_block_item_right">
                            <div class="services_block_item_right_top">
                                <div class="services_block_item_right_top_arrow">
                                    <img src="img/icons/arrow.svg" class="services_block_item_right_top_arrow_img"
                                        loading="lazy" decoding="async" alt="иконка стрелки">
                                </div>
                                <div class="services_block_item_right_top_price">
                                    от <strong>5000</strong> ₽
                                </div>
                            </div>
                            <div class="services_block_item_right_bottom">
                                <div class="services_block_item_right_bottom_name">
                                    <strong>Публикация и продвижение видео</strong>
                                </div>
                                <div class="services_block_item_right_bottom_description">
                                    Опытный продюсер поможет с анонсом, публикацией видео на площадках и продвижением
                                    видео
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="services_block_item">
                        <div class="services_block_item_left">
                            <img src="img/services/5.jpg" loading="lazy" decoding="async" alt="услуга монтаж подкаста"
                                class="services_block_item_left_img">
                        </div>
                        <div class="services_block_item_right">
                            <div class="services_block_item_right_top">
                                <div class="services_block_item_right_top_arrow">
                                    <img src="img/icons/arrow.svg" class="services_block_item_right_top_arrow_img"
                                        loading="lazy" decoding="async" alt="иконка стрелки">
                                </div>
                                <div class="services_block_item_right_top_price">
                                    от <strong>10000</strong> ₽
                                </div>
                            </div>
                            <div class="services_block_item_right_bottom">
                                <div class="services_block_item_right_bottom_name">
                                    <strong>Пакетные решения</strong>
                                </div>
                                <div class="services_block_item_right_bottom_description">
                                    - Выездные съемки видео (сценарий, запись, монтаж) <br>
                                    - Съемки рилс под ключ (сценарий, запись, монтаж)
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="services_block_item">
                        <div class="services_block_item_left">
                            <img src="img/services/6.jpg" loading="lazy" decoding="async" alt="услуга монтаж подкаста"
                                class="services_block_item_left_img">
                        </div>
                        <div class="services_block_item_right">
                            <div class="services_block_item_right_top">
                                <div class="services_block_item_right_top_arrow">
                                    <img src="img/icons/arrow.svg" class="services_block_item_right_top_arrow_img"
                                        loading="lazy" decoding="async" alt="иконка стрелки">
                                </div>
                                <div class="services_block_item_right_top_price">
                                    от <strong>10000</strong> ₽
                                </div>
                            </div>
                            <div class="services_block_item_right_bottom">
                                <div class="services_block_item_right_bottom_name">
                                    <strong>Создание подкаста под ключ</strong>
                                </div>
                                <div class="services_block_item_right_bottom_description">
                                    - Стилизация и декор студии под Ваш подкаст <br>
                                    - Идея, монтаж и продвижение видео
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- <section class="reviews">
            <div class="reviews_wrapper">
                <div class="reviews_left">
                    <div class="reviews_left_sub_title">
                        Нам важно ваше мнение
                    </div>
                    <h2 class="reviews_left_title">
                        отзывы
                    </h2>
                    <div class="reviews_left_description">
                        Поможем вам качественно, легко и комфортно записать подкаст, видеокурс, аудиокнигу, интервью,
                        медитации, шоу или любой другой нужный вам формат.
                    </div>
                </div>
                <div class="reviews_right">
                    <div class="reviews_right_wrapper">
                        <div class="swiper swiper_reviews">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide swiper-slide_reviews">
                                    <div class="swiper-slide-content  swiper-slide-content_reviews">
                                        <div class="swiper-slide-content_reviews_photo">
                                            <img src="img/people/1.webp" loading="lazy" decoding="async"  alt="фото человека 2"
                                                class="swiper-slide-content_reviews_img">
                                        </div>
                                        <div class="swiper-slide-content_reviews_info">
                                            <div class="swiper-slide-content_reviews_info_top">
                                                Сайт просто супер. Ребята молодцы, делают свою работу на высоком уровне.
                                                Товары всегда новые, цены вполне доступные. Часто проводятся скидки,
                                                акции, что особо радует :) Буду рекомендовать всем друзьям и близким.
                                            </div>
                                            <div class="swiper-slide-content_reviews_info_bottom">
                                                <div class="content_reviews_info_bottom_fio">
                                                    Володин дмитрий
                                                </div>
                                                <div class="content_reviews_info_bottom_apostraf">
                                                    <img src="img/icons/apostraf.svg" loading="lazy" decoding="async" alt="картинка апострафа"
                                                        class="content_reviews_info_bottom_apostraf_img">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="swiper-slide swiper-slide_reviews">
                                    <div class="swiper-slide-content  swiper-slide-content_reviews">
                                        <div class="swiper-slide-content_reviews_photo">
                                            <img src="img/people/2.webp"  loading="lazy" decoding="async" alt="фото человека 2"
                                                class="swiper-slide-content_reviews_img">
                                        </div>
                                        <div class="swiper-slide-content_reviews_info">
                                            <div class="swiper-slide-content_reviews_info_top">
                                                Сайт просто супер. Ребята молодцы, делают свою работу на высоком уровне.
                                                Товары всегда новые, цены вполне доступные. Часто проводятся скидки,
                                                акции, что особо радует :) Буду рекомендовать всем друзьям и близким.
                                            </div>
                                            <div class="swiper-slide-content_reviews_info_bottom">
                                                <div class="content_reviews_info_bottom_fio">
                                                    Яковлев владимир
                                                </div>
                                                <div class="content_reviews_info_bottom_apostraf">
                                                    <img src="img/icons/apostraf.svg" loading="lazy" decoding="async"  alt="картинка апострафа"
                                                        class="content_reviews_info_bottom_apostraf_img">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- <section class="sotrudnichestvo">
            <div class="sotrudnichestvo_wrapper">
                <div class="sotrudnichestvo_item">
                    <img src="img/sotrudnichestvo/1.webp"  loading="lazy" decoding="async" alt="картинка партнёра 1" class="sotrudnichestvo_item_img">
                </div>
                <div class="sotrudnichestvo_item">
                    <img src="img/sotrudnichestvo/2.webp"  loading="lazy" decoding="async" alt="картинка партнёра 2" class="sotrudnichestvo_item_img">
                </div>
                <div class="sotrudnichestvo_item">
                    <img src="img/sotrudnichestvo/3.webp"  loading="lazy" decoding="async" alt="картинка партнёра 3" class="sotrudnichestvo_item_img">
                </div>
                <div class="sotrudnichestvo_item">
                    <img src="img/sotrudnichestvo/4.webp"  loading="lazy" decoding="async" alt="картинка партнёра 4" class="sotrudnichestvo_item_img">
                </div>
            </div>
        </section> -->
        <!-- <section class="our_works">
            <div class="our_works_wrapper">
                <div class="our_works_sub_title">
                    подкасты, записанные у нас
                </div>
                <h2 class="our_works_title">
                    наши работы
                </h2>
                <div class="our_works_content">
                    <a href="https://www.youtube.com/watch?v=vUTNm89_0Qc" class="our_works_content_item">
                        <img src="img/services/1.webp"  loading="lazy" decoding="async" alt="картинка для видео 1" class="our_works_content_item_img">
                        <div class="our_works_content_item_overlay"></div>
                        <div class="our_works_content_item_btn_play">
                            <img src="img/icons/play-solid.svg"  loading="lazy" decoding="async" alt="иконка Play">
                        </div>
                    </a>
                    <a href="https://www.youtube.com/watch?v=vUTNm89_0Qc" class="our_works_content_item">
                        <img src="img/services/1.webp"  loading="lazy" decoding="async" alt="картинка для видео 2" class="our_works_content_item_img">
                        <div class="our_works_content_item_overlay"></div>
                        <div class="our_works_content_item_btn_play">
                            <img src="img/icons/play-solid.svg"  loading="lazy" decoding="async" alt="иконка Play">
                        </div>
                    </a>
                    <a href="https://www.youtube.com/watch?v=vUTNm89_0Qc" class="our_works_content_item">
                        <img src="img/services/1.webp"  loading="lazy" decoding="async" alt="картинка для видео 3" class="our_works_content_item_img">
                        <div class="our_works_content_item_overlay"></div>
                        <div class="our_works_content_item_btn_play">
                            <img src="img/icons/play-solid.svg"  loading="lazy" decoding="async" alt="иконка Play">
                        </div>
                    </a>
                </div>
            </div>
        </section> -->
    </main>
    <?php include 'include/footer.php'; ?>
    <!-- Swiper и ваши модули -->
    <script defer src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script defer src="js/swiper_oborydovanie.js"></script>
    <script defer src="js/swiper_location.js"></script>
    <script defer src="js/swiper_reviews.js"></script>
    <script defer src="js/share-modal.js"></script>
    <script src="js/fslightboxx.js?v=<?= time() ?>"></script>

    <!-- Yandex.Metrika (часть юзеров = AdBlock  → ok) -->
    <script async src="https://mc.yandex.ru/metrika/tag.js"></script>
    <script>
        window.ym = window.ym || function () { (ym.a = ym.a || []).push(arguments) };
        ym(101462745, 'init', { clickmap: true, trackLinks: true, accurateTrackBounce: true, webvisor: true });

        /* пример безопасной цели */
        function goal(btn) {
            if (typeof ym === 'function') ym(101462745, 'reachGoal', btn);
        }
    </script>
    <noscript><img src="https://mc.yandex.ru/watch/101462745" style="position:absolute;left:-9999px" alt=""></noscript>

    <script async src='//widjet.matomba.ru/quiz/0c409d0fe4178a457834e477337024bc'></script>


</body>

</html>