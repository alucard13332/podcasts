// js/share-modal.js
document.addEventListener('DOMContentLoaded', () => {
  const btn = document.querySelector('.share-btn');   // <-- ваш селектор
  if (btn) btn.addEventListener('click', openShareModal);
});

function openShareModal() { /* … */ }
