<?php
// Auto SEO Box — Premium установщик
session_start();
define('CONFIG_FILE', __DIR__.'/storage/config.json');

function page($body) {
    echo <<<HTML
<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>⚡ Auto SEO Box — Установка</title>
    <style>
    :root {
        --primary: #6e48aa;
        --secondary: #9d50bb;
        --accent: #4776E6;
        --dark: #2c3e50;
        --light: #f9f9f9;
        --success: #2ecc71;
        --danger: #e74c3c;
        --warning: #f39c12;
    }
    * { box-sizing: border-box; }
    body {
        font-family: 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
        line-height: 1.6;
        color: #333;
        background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
        margin: 0;
        padding: 0;
        min-height: 100vh;
    }
    .container {
        max-width: 700px;
        margin: 0 auto;
        padding: 2rem;
    }
    .card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        overflow: hidden;
        margin-bottom: 2rem;
    }
    .card-header {
        background: linear-gradient(to right, var(--primary), var(--secondary));
        color: white;
        padding: 1.5rem;
        text-align: center;
    }
    .card-body { padding: 2rem; }
    .form-group { margin-bottom: 1.5rem; }
    label {
        display: block;
        margin-bottom: 0.5rem;
        font-weight: 600;
        color: var(--dark);
    }
    input, select, textarea, button {
        width: 100%;
        padding: 12px 15px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 16px;
        transition: all 0.3s;
    }
    input:focus, select:focus, textarea:focus {
        border-color: var(--accent);
        box-shadow: 0 0 0 3px rgba(71, 118, 230, 0.2);
        outline: none;
    }
    button {
        background: linear-gradient(to right, var(--primary), var(--secondary));
        color: white;
        border: none;
        font-weight: 600;
        cursor: pointer;
        padding: 15px;
        margin-top: 10px;
        font-size: 18px;
    }
    button:hover {
        opacity: 0.9;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    .btn-group {
        display: flex;
        gap: 10px;
        margin-top: 20px;
    }
    .btn-outline {
        background: white;
        color: var(--primary);
        border: 2px solid var(--primary);
    }
    .btn-outline:hover {
        background: var(--primary);
        color: white;
    }
    .alert {
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 1.5rem;
    }
    .alert-success {
        background-color: rgba(46, 204, 113, 0.2);
        border-left: 4px solid var(--success);
    }
    .alert-danger {
        background-color: rgba(231, 76, 60, 0.2);
        border-left: 4px solid var(--danger);
    }
    .alert-warning {
        background-color: rgba(243, 156, 18, 0.2);
        border-left: 4px solid var(--warning);
    }
    .badge {
        display: inline-block;
        padding: 3px 8px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: bold;
        background: var(--accent);
        color: white;
        vertical-align: middle;
    }
    .grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 15px;
    }
    .note {
        font-size: 14px;
        color: #666;
        margin-top: 5px;
    }
    </style>
</head>
<body>
    <div class="container">
        {$body}
    </div>
</body>
</html>
HTML;
}

function validate_url($url) {
    return filter_var($url, FILTER_VALIDATE_URL) && preg_match('/^https?:\/\//i', $url);
}

// Проверка прав
if (!is_writable(__DIR__)) {
    page('
    <div class="card">
        <div class="card-header">
            <h1>❌ Ошибка установки</h1>
        </div>
        <div class="card-body">
            <div class="alert alert-danger">
                <strong>Недостаточно прав!</strong> Установите chmod 755 для текущей директории.
            </div>
            <p>Выполните в терминале:</p>
            <pre>chmod 755 '.htmlspecialchars(__DIR__).'</pre>
        </div>
    </div>');
    exit;
}

// Основная форма
if (empty($_POST)) {
    page('
    <div class="card">
        <div class="card-header">
            <h1>🚀 Установка Auto SEO Box</h1>
            <p>Автоматическая генерация SEO-оптимизированных статей</p>
        </div>
        <div class="card-body">
            <form method="post">
                <div class="grid">
                    <div class="form-group">
                        <label>🌐 Адрес сайта</label>
                        <input type="url" name="site_url" required placeholder="https://example.com/">
                        <div class="note">Обязательно добавьте слеш в конце (/)</div>
                    </div>
                    <div class="form-group">
                        <label>📍 Регион таргетинга</label>
                        <input name="region" value="Россия" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>📛 Название сайта</label>
                    <input name="site_title" required placeholder="Мой супер сайт">
                </div>
                
                <div class="form-group">
                    <label>📌 Основная тема статей</label>
                    <input name="main_topic" required placeholder="Здоровый образ жизни">
                </div>
                
                <div class="form-group">
                    <label>🏷️ Ключевые слова (через запятую)</label>
                    <textarea name="tags" rows="3" required placeholder="фитнес, здоровье, упражнения, тренировка"></textarea>
                </div>
                
                <div class="form-group">
                    <label>🔑 Mode Key <span class="badge">PREMIUM</span></label>
                    <input name="mode_key" required placeholder="Получите у разработчика">
                    <div class="note">Без ключа генерация работать не будет. Получите на <a href="https://autoseobox.store" target="_blank">autoseobox.store</a></div>
                </div>
                
                <div class="grid">
                    <div class="form-group">
                        <label>📅 Интервал генерации</label>
                        <select name="frequency">
                            <option value="1">Ежедневно</option>
                            <option value="3" selected>Каждые 3 дня</option>
                            <option value="7">Еженедельно</option>
                            <option value="14">Раз в 2 недели</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>📝 Объём статьи</label>
                        <select name="min_words">
                            <option value="30">30 слов</option>
                            <option value="60" selected>60 слов</option>
                            <option value="80">80 слов</option>
                            <option value="100">100 слов</option>
                        </select>
                    </div>
                </div>
                
                <div class="alert alert-warning">
                    <strong>Важно!</strong> Для работы добавьте в начало вашего <code>index.php</code>:
                    <pre style="background:#f8f9fa;padding:10px;border-radius:5px">&lt;?php require_once __DIR__.\'/autoseo.php\'; ?&gt;</pre>
                </div>
                
                <button type="submit">⚡ Установить Auto SEO Box</button>
            </form>
        </div>
    </div>');
    exit;
}

// Обработка формы
$errors = [];
if (!validate_url($_POST['site_url'])) {
    $errors[] = "Некорректный URL сайта (должен начинаться с http:// или https://)";
}

// Автоматическое добавление слеша в конец URL
$site_url = rtrim($_POST['site_url'], '/').'/';

$tags = array_filter(array_map('trim', explode(',', $_POST['tags'])));
if (count($tags) < 3) {
    $errors[] = "Укажите минимум 3 ключевых слова";
}

if (empty($_POST['mode_key'])) {
    $errors[] = "Необходимо указать Mode Key";
}

if (!empty($errors)) {
    page('
    <div class="card">
        <div class="card-header">
            <h1>❌ Ошибки ввода</h1>
        </div>
        <div class="card-body">
            <div class="alert alert-danger">
                <strong>'.implode("<br>", $errors).'</strong>
            </div>
            <a href="javascript:history.back()" style="display:inline-block;margin-top:15px;color:var(--accent)">← Вернуться назад</a>
        </div>
    </div>');
    exit;
}

// Создание конфига
$config = [
    'site_url'    => $site_url, // URL уже со слешем
    'title'       => $_POST['site_title'],
    'main_topic'  => $_POST['main_topic'],
    'tags'        => $tags,
    'region'      => $_POST['region'],
    'frequency'   => (int)$_POST['frequency'],
    'min_words'   => (int)$_POST['min_words'],
    'mode_key'    => trim($_POST['mode_key']),
    'max_tokens'  => 2048,
    'log_level'   => 'INFO',
    'indexnow_key' => bin2hex(random_bytes(16))
];

@mkdir(__DIR__.'/storage', 0775, true);
@mkdir(__DIR__.'/storage/articles', 0775, true);
file_put_contents(CONFIG_FILE, json_encode($config, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));

// Аккуратное добавление в .htaccess
$htaccess_file = __DIR__.'/.htaccess';
$required_lines = [
    "# Auto SEO Box",
    "<IfModule mod_php7.c>",
    "    php_value auto_prepend_file ".str_replace($_SERVER['DOCUMENT_ROOT'], '', __DIR__)."/autoseo.php",
    "</IfModule>",
    "<IfModule mod_php.c>",
    "    php_value auto_prepend_file ".str_replace($_SERVER['DOCUMENT_ROOT'], '', __DIR__)."/autoseo.php",
    "</IfModule>",
    "",
    "# Защита файлов AutoSEO",
    "<FilesMatch \"\.(json|log|lock)$\">",
    "    Require all denied",
    "</FilesMatch>"
];

if (file_exists($htaccess_file)) {
    $current_content = file_get_contents($htaccess_file);
    $missing_lines = array_diff($required_lines, explode("\n", $current_content));
    
    if (!empty($missing_lines)) {
        $new_content = $current_content . "\n\n" . implode("\n", $required_lines);
        file_put_contents($htaccess_file, $new_content);
    }
} else {
    file_put_contents($htaccess_file, implode("\n", $required_lines));
}

// Создание шаблона статьи
@mkdir(__DIR__.'/templates', 0775, true);
$template = <<<HTML
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{TITLE}} | {$config['site_title']}</title>
    <meta name="description" content="Статья на тему {{TITLE}}">
    <style>
        body {font-family: Arial, sans-serif; line-height: 1.6; max-width: 800px; margin: 0 auto; padding: 20px}
        h1 {color: #2c3e50; border-bottom: 1px solid #eee; padding-bottom: 10px}
        h2 {color: #34495e; margin-top: 30px}
        img {max-width: 100%; height: auto; border-radius: 8px}
        .content {margin: 20px 0}
        footer {color: #7f8c8d; font-size: 14px; margin-top: 40px}
    </style>
</head>
<body>
    <article>
        <h1>{{TITLE}}</h1>
        <div class="content">{{CONTENT}}</div>
        <footer>Опубликовано: {{DATE}}</footer>
    </article>
</body>
</html>
HTML;

file_put_contents(__DIR__.'/templates/article.html', $template);
file_put_contents(__DIR__.'/storage/guest.log', '');
file_put_contents(__DIR__.'/storage/seo.log', '');
// Результат установки
page('
<div class="card">
    <div class="card-header">
        <h1>🎉 Установка завершена!</h1>
    </div>
    <div class="card-body">
        <div class="alert alert-success">
            <h3>Обязательно выполните:</h3>
            <ol>
                <li>Удалите файл <code>install.php</code></li>
                <li>Добавьте в начало вашего <code>index.php</code>:
                    <pre style="background:#f8f9fa;padding:10px;border-radius:5px">&lt;?php require_once __DIR__.\'/autoseo.php\'; ?&gt;</pre>
                </li>
            </ol>
        </div>
        
        <h3>📊 Параметры генерации:</h3>
        <ul>
            <li><strong>Сайт:</strong> '.htmlspecialchars($config['site_url']).'</li>
            <li><strong>Частота:</strong> каждые '.$config['frequency'].' дня</li>
            <li><strong>Объём статей:</strong> '.$config['min_words'].' слов</li>
            <li><strong>Основная тема:</strong> '.htmlspecialchars($config['main_topic']).'</li>
        </ul>
        
        <h3>📂 Где смотреть результаты?</h3>
        <ul>
            <li>Логи: <code>'.htmlspecialchars($config['site_url']).'storage/seo.log</code></li>
                        <li>Логи посешений: <code>'.htmlspecialchars($config['site_url']).'/guest.php</code></li>
            <li>Статьи: <code>'.htmlspecialchars($config['site_url']).'storage/articles/</code></li>
        </ul>
        
        <div class="btn-group">
            <a href="https://autoseobox.store/" target="_blank" class="btn-outline" style="text-decoration:none;text-align:center">
                🌐 Сайт модуля
            </a>
            <a href="https://t.me/workwebphp" target="_blank" class="btn-outline" style="text-decoration:none;text-align:center">
                💬 Техподдержка в Telegram
            </a>
        </div>
        
        <a href="'.$config['site_url'].'" style="display:block;margin-top:20px;color:white;background:var(--primary);padding:12px;border-radius:8px;text-decoration:none;font-weight:bold;text-align:center">
            Перейти на сайт →
        </a>
    </div>
</div>');